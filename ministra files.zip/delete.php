<?php
// Author : Paul Moore
// Project : In2streams.co Video CMS
include('config.php');

include('functions2/db.php');
function GetSQLValueString($theValue = '', $theType) 
{

  $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;

  if(is_string($theValue)) { $theValue = function_exists("mysqli_real_escape_string") ? mysqli_real_escape_string($GLOBALS['__Connect'],$theValue) : $theValue;}

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}

$db1 = new db;
$db1->connect(); 
if($_GET['user'] != ministra_user or $_GET['pass'] != ministra_pass){
	echo 'Error: Ministra login failed'; exit;}
if(isset($_GET['mac']) and isset($_GET['id']))
{
	$insertSQL = sprintf("DELETE FROM users where id=%s",
  				   GetSQLValueString($_GET['id'], "text",$GLOBALS['__Connect']));
  $Result1 = mysqli_query($GLOBALS['__Connect'],$insertSQL) or die(mysqli_error($GLOBALS['__Connect']));
}
elseif(isset($_GET['mac']) and !isset($_GET['id'])){
	
	$insertSQL = sprintf("DELETE FROM users where mac=%s",
  				   GetSQLValueString($_GET['mac'], "text",$GLOBALS['__Connect']));
  $Result1 = mysqli_query($GLOBALS['__Connect'],$insertSQL) or die(mysqli_error($GLOBALS['__Connect']));

	?><?php }
?>Added