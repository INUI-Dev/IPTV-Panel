<?php
// Author : Paul Moore
// Project : In2streams.co Video CMS
include('config.php');

include('functions2/db.php');
function GetSQLValueString($theValue = '', $theType) 
{

  $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;

  if(is_string($theValue)) { $theValue = function_exists("mysqli_real_escape_string") ? mysqli_real_escape_string($GLOBALS['__Connect'],$theValue) : $theValue;}

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}

$db1 = new db;
$db1->connect(); 
if($_GET['user'] != ministra_user or $_GET['pass'] != ministra_pass){
	echo 'Error: Ministra login failed'; exit;}
$content['tariff'] = $db1->db_query("SELECT * FROM tariff_plan"." order by id desc",array ('id','name'
),2,0,true);
if(isset($_GET['mac']))
{
	$content['mac'] = $db1->db_query("SELECT * FROM users where mac = ".GetSQLValueString($_GET['mac'], "text",$GLOBALS['__Connect'])." order by id desc",array ('id'
),1,0,true);
if($content['mac'][0]['is_empty'] == 'false'){
	
$insertSQL = sprintf("UPDATE users set tariff_plan_id=%s,theme='default' where mac=%s",
  
 		   GetSQLValueString($_GET['tariff'], "int",$GLOBALS['__Connect']),
					   GetSQLValueString($_GET['mac'].' ', "text",$GLOBALS['__Connect']));
  $Result1 = mysqli_query($GLOBALS['__Connect'],$insertSQL) or die(mysqli_error($GLOBALS['__Connect']));
}
else
{
	
	

	$nname = explode(':',$_GET['mac']);
$insertSQL = sprintf("INSERT INTO users(mac, name,tariff_plan_id,theme,login) VALUES(%s,%s,%s,'default',%s)",
  
					   GetSQLValueString($_GET['mac'], "text",$GLOBALS['__Connect']),
 		   GetSQLValueString($nname[4].':'.$nname[5], "text",$GLOBALS['__Connect']),
					   GetSQLValueString($_GET['tariff'] ,"int",$GLOBALS['__Connect']),
					   GetSQLValueString($_GET['login'], "text",$GLOBALS['__Connect']));
  $Result1 = mysqli_query($GLOBALS['__Connect'],$insertSQL) or die(mysqli_error($GLOBALS['__Connect']));
  
  
  
$content['insert_id'] = $db1->db_query("SELECT * FROM users WHERE mac = ".GetSQLValueString($_GET['mac'], "text",$GLOBALS['__Connect'])." order by id desc",array ('id'
),1,0,true);
  $insertSQL = sprintf("UPDATE users SET password=%s where mac=%s",
  GetSQLValueString(md5(md5($_GET['loginpass']).$content['insert_id'][0]['id']), "text",$GLOBALS['__Connect']),
  GetSQLValueString($_GET['mac'].' ', "text",$GLOBALS['__Connect']));
  $Result1 = mysqli_query($GLOBALS['__Connect'],$insertSQL) or die(mysqli_error($GLOBALS['__Connect']));
  

  
}
}
else{
	?><?php }
?>Added