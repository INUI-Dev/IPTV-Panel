<?php
// Author : Paul Moore
// Project : In2streams.co Video CMS
include('config.php');

include('functions2/db.php');
function GetSQLValueString($theValue = '', $theType) 
{

  $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;

  if(is_string($theValue)) { $theValue = function_exists("mysqli_real_escape_string") ? mysqli_real_escape_string($GLOBALS['__Connect'],$theValue) : $theValue;}

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}

$db1 = new db;
$db1->connect(); 
$insertSQL = sprintf("delete from itv"); 
$Result1 = mysqli_query($GLOBALS['__Connect'],$insertSQL) or die(mysqli_error($GLOBALS['__Connect']));

$insertSQL = sprintf("delete from ch_links"); 
$Result1 = mysqli_query($GLOBALS['__Connect'],$insertSQL) or die(mysqli_error($GLOBALS['__Connect']));