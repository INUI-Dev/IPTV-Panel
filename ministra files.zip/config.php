<?php 

if(isset($_GET['errors']))
{
	
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
}
define('hostname_portfolio','localhost');
define('database_portfolio' ,'stalker_db');
define('username_portfolio','root');
define('password_portfolio' ,'st@lk3r');

 define('ministra_user','user');
 define('ministra_pass','pass'); ?>