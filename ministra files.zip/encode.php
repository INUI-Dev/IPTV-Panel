<?php
echo urlencode('http://demo.in2iptv.com/iptv.php?user=admin&pass=5765&list=new.m3u');