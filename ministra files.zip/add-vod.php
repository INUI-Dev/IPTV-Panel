<?php 
// Author : Paul Moore
// Project : In2streams.co Video CMS
include('config.php');

include('functions2/db.php');
function GetSQLValueString($theValue = '', $theType) 
{

  $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;

  if(is_string($theValue)) { $theValue = function_exists("mysqli_real_escape_string") ? mysqli_real_escape_string($GLOBALS['__Connect'],$theValue) : $theValue;}

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}


if($_GET['user'] != ministra_user or $_GET['pass'] != ministra_pass){
	echo 'Error: Ministra login failed'; exit;}
$db1 = new db;
$db1->connect(); 
$content['category'] = $db1->db_query("SELECT * FROM video",array ('id','name','category_id','fname','pic'
),50000,0,true,true);
if($content['category'][0]['is_empty'] == 'false')

{
	$int1 = 0;
	echo '#EXTM3U
	';

foreach($content['category'] as $items)
{ $content['vid'] = $db1->db_query("SELECT * FROM video_series_files where video_id=".$items['id'],array ('id','url'
),50000,0,true,true);

$content['genre'] = $db1->db_query("SELECT * FROM genre where id=".$items['category_id'],array ('title'
),50000,0,true,true);

echo '#EXTINF:-1 tvg-ID="" tvg-name="'.$items['name'].'" tvg-logo="'. $items['pic'].'" group-title="'.$content['genre'][0]['title'].'",'.$items['name'].'
'.str_replace('ffmpeg ','',$content['vid'][0]['url']).'
';
}
}
?>