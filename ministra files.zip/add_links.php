<?php
// Author : Paul Moore
// Project : In2streams.co Video CMS
include('config.php');

include('functions2/db.php');
function GetSQLValueString($theValue = '', $theType) 
{

  $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;

  if(is_string($theValue)) { $theValue = function_exists("mysqli_real_escape_string") ? mysqli_real_escape_string($GLOBALS['__Connect'],$theValue) : $theValue;}

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}

$db1 = new db;
$db1->connect(); 
if($_GET['user'] != ministra_user or $_GET['pass'] != ministra_pass){
	echo 'Error: Ministra login failed'; exit;}

if(isset($_GET['url']))
{
$db1->set_m3u(str_replace(":-1",":0",file_get_contents($_GET['url'])),' v');
}
else{
	?><?php }
?>Added